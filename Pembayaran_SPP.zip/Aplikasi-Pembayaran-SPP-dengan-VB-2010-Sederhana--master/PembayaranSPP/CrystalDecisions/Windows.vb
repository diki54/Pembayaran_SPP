﻿Namespace CrystalDecisions
    Friend Class Windows
    End Class
End Namespace
